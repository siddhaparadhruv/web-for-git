// Script for navigation bar
